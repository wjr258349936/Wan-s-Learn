//
// Created by lenovo on 2025/11/14.
//
#include "BSTree.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
BSTree *initBSTree(){
    BSTree *tree = createBSTree();

    insertBSTreeNode(tree,22);
    insertBSTreeNode(tree,33);
    insertBSTreeNode(tree,45);
    insertBSTreeNode(tree,55);
    insertBSTreeNode(tree,8);
    insertBSTreeNode(tree,80);
    insertBSTreeNode(tree,130);
    insertBSTreeNode(tree,100);
    insertBSTreeNode(tree,120);
    insertBSTreeNode(tree,121);

    return tree;
}

void test01(){
    BSTree* tree = initBSTree();
    InOrderBSTree(tree);
    BSTreeNode *node = searchBSTreeNode(tree,120);
    if(node){
        printf("%d\n",node->data);
    }
   /* visitBSTreeNode(tree->root);*/
    printf("%d\n", heightBSTree(tree));
    releaseBSTree(tree);
}

void test02() {
    int n = 1000000;
    srand(time(NULL) + 1);
    element_t *data = malloc(sizeof(element_t) * n);

    // 生成不重复的随机数据
    for (int i = 0; i < n; ++i) {
        data[i] = i + 1;  // 使用1到n的连续数字确保不重复
    }

    // 打乱数组
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        element_t temp = data[i];
        data[i] = data[j];
        data[j] = temp;
    }

    int cnt = 5000;

    // 线性搜索测试
    int linear_results = 0;
    clock_t start = clock();
    for (int i = 0; i < cnt; ++i) {
        int found = 0;
        for (int j = 0; j < n; ++j) {
            if (data[j] == n + 5000) {
                found = 1;
                break;
            }
        }
        linear_results += found;
    }
    clock_t end = clock();
    double linear_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("linear find cost %fs, found: %d\n", linear_time, linear_results);
    printf("==============================\n");

    // 构建BSTree
    printf("Building BSTree...\n");
    BSTree *tree = createBSTree();
    for (int i = 0; i < n; ++i) {
        insertBSTreeNode(tree, data[i]);
        if ((i + 1) % 100000 == 0) {
            printf("Inserted %d nodes...\n", i + 1);
        }
    }
    printf("BSTree built with %d nodes, height: %d\n", tree->count, heightBSTree(tree));

    if (tree->count != n) {
        printf("WARNING: Expected %d nodes, but got %d nodes\n", n, tree->count);
    }

    // BSTree搜索测试 - 增加测试次数
    cnt = 100000;  // 增加到10万次
    start = clock();
    int bst_results = 0;
    long long checksum = 0;  // 用于防止优化

    for (int i = 0; i < cnt; ++i) {
        BSTreeNode *res = searchBSTreeNode(tree, n + 5000);  // 搜索不存在的值
        if (res != NULL) {
            bst_results++;
            checksum += res->data;  // 使用结果防止优化
        } else {
            checksum += i;  // 即使没找到也要计算
        }
    }
    end = clock();

    // 强制使用checksum
    if (checksum == 0) {
        printf("checksum: %lld\n", checksum);
    }

    double bst_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("BSTree find cost %fs, found: %d (after %d searches)\n", bst_time, bst_results, cnt);

    if (bst_time > 0) {
        printf("Speedup: %.2fx\n", linear_time / bst_time * (5000.0 / cnt));
    } else {
        printf("BSTree time is too small, increasing search count...\n");

        // 如果还是太小，再次增加搜索次数
        cnt = 1000000;  // 100万次
        start = clock();
        for (int i = 0; i < cnt; ++i) {
            BSTreeNode *res = searchBSTreeNode(tree, n + 5000);
            if (res != NULL) {
                checksum += res->data;
            }
        }
        end = clock();
        bst_time = (double)(end - start) / CLOCKS_PER_SEC;
        printf("BSTree find cost %fs (after %d searches)\n", bst_time, cnt);
    }

    releaseBSTree(tree);
    free(data);
}

int main(){
    /*test01();*/
    test02();
    return 0;
}

